# IA_Music
Zone de Test pour réaliser en un seul code toutes les acquisitions nécessaire pour notre futur IA
